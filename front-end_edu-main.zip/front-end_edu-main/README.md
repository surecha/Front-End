# front-end_edu
프로젝트 기반의 프론트엔드 프로그래밍 강의용 자료

## 웹 폰트 정보
사용한 웹 폰트(구글 폰트) - https://fonts.google.com/
* Gowun Dodum(고운 돋음)<br>
https://fonts.google.com/specimen/Gowun+Dodum?query=gowun

* Nova Square<br>
https://fonts.google.com/specimen/Nova+Square

# 과제 제출
한컴 한글 문서에 각 페이지의 스크린샷을 저장하여 제출

파일명 : '프론트엔드_홍길동.hwp'
